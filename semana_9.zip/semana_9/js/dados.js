const minhas_imagens = [
    {
        nome: 'Número 1',
        valor: 1,
        descricao: 'Número 1 com fundo amarelo.'
    },
    {
        nome: 'Número 2',
        valor: 2,
        descricao: 'Número 2 com fundo vermelho.'
    },
    {
        nome: 'Número 3',
        valor: 3,
        descricao: 'Número 3 vermelho em 3D.'
    }
];